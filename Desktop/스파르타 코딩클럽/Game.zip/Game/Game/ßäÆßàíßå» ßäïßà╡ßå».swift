////씻기
////운동> 밥주기처럼 만들기
//
////타이머 > dirty 증가
////레벨 증가
//Button() {
//    isSelected == true
//} label: {
//    Image(systemName: "circle")
//        .opacity (isSelected ? 0.0 : 1)
//        .disabled (isSelected
